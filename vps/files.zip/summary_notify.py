"""
サマリー通知スクリプト（7/12/16/21時実行）
- 現在の口座状況・ポジション・損益をDiscordに送信
- 決済済みポジションの通知も含む
"""
import MetaTrader5 as mt5
import json, os, ssl, urllib.request
from datetime import datetime, date

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_PATH = os.path.join(BASE_DIR, '.env')
LOG_PATH = os.path.join(BASE_DIR, 'trade_log.json')

STRATEGY_CONFIG = {
    'TRI':    {'max_pos':1},
    'MOM_JPY':{'max_pos':1},
    'MOM_GBJ':{'max_pos':1},
    'CORR':   {'max_pos':1},
    'STR':    {'max_pos':1},
}
MAX_TOTAL = 6

def load_env():
    config = {}
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if '=' in line and not line.startswith('#'):
                    k, v = line.split('=', 1)
                    config[k.strip()] = v.strip()
    return config

def send_discord(message, webhook):
    if not webhook: return
    data = json.dumps({'content': message}).encode('utf-8')
    req  = urllib.request.Request(webhook, data=data,
           headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0'})
    try:
        urllib.request.urlopen(req, context=ssl._create_unverified_context())
        print("Discord通知完了")
    except Exception as e:
        print(f"Discord送信エラー: {e}")

def load_log():
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, encoding='utf-8') as f:
            return json.load(f)
    return {'date':str(date.today()),'initial_balance':0,
            'orders':[],'closed':[],'daily_loss_stopped':False}

def save_log(log):
    with open(LOG_PATH, 'w', encoding='utf-8') as f:
        json.dump(log, f, ensure_ascii=False, indent=2)

def get_positions():
    p = mt5.positions_get()
    return list(p) if p else []

def count_by(strategy):
    return sum(1 for p in get_positions() if strategy in p.comment)

def check_closed(log, webhook):
    if not log['orders']: return
    current      = {p.ticket for p in get_positions()}
    newly_closed = [o for o in log['orders'] if o['ticket'] not in current]
    if not newly_closed: return
    from_date = datetime(date.today().year, date.today().month, date.today().day)
    deals     = mt5.history_deals_get(from_date, datetime.now())
    deal_map  = {d.order:d for d in deals} if deals else {}
    now       = datetime.now().strftime('%Y-%m-%d %H:%M')
    for order in newly_closed:
        deal   = deal_map.get(order['ticket'])
        profit = deal.profit if deal else 0
        emoji  = '✅' if profit>=0 else '❌'
        reason = '利確' if profit>=0 else '損切'
        send_discord(
            f"【FX Bot】{now}\n{emoji} **{reason}確定**\n"
            f"通貨ペア: {order['symbol']}\n方向: {order['direction']}\n"
            f"損益: {'+' if profit>=0 else ''}{profit:,.0f}円\n戦略: {order['strategy']}",
            webhook
        )
        log['closed'].append({**order,'profit':profit,'reason':reason})
    closed_tickets = {o['ticket'] for o in newly_closed}
    log['orders']  = [o for o in log['orders'] if o['ticket'] not in closed_tickets]
    save_log(log)

def main():
    config  = load_env()
    webhook = config.get('DISCORD_WEBHOOK','')

    if not mt5.initialize():
        print("MT5接続失敗"); return

    log       = load_log()
    now       = datetime.now().strftime('%Y-%m-%d %H:%M')
    info      = mt5.account_info()
    initial   = log['initial_balance']
    pnl       = info.equity - initial
    positions = get_positions()

    check_closed(log, webhook)

    pos_text = ''
    for p in positions:
        strategy = p.comment.replace('FXBot_','')
        dir_jp   = '買い' if p.type==0 else '売り'
        pos_text += f"\n  [{strategy}] {p.symbol} {dir_jp} {p.volume}lot " \
                    f"損益:{'+' if p.profit>=0 else ''}{p.profit:,.0f}円"

    total_closed = sum(c.get('profit',0) for c in log['closed'])
    closed_text  = (f"\n本日決済: {len(log['closed'])}回 "
                    f"合計{'+' if total_closed>=0 else ''}{total_closed:,.0f}円"
                    if log['closed'] else '')

    strategy_lines = '\n'.join(
        f"  {s}: {count_by(s)}/{cfg['max_pos']}"
        for s, cfg in STRATEGY_CONFIG.items()
    )

    send_discord(
        f"【FX Bot】{now} 日次サマリー\n\n"
        f"**■ 口座状況**\n残高: {info.balance:,.0f}円\n資産: {info.equity:,.0f}円\n"
        f"本日損益: {'+' if pnl>=0 else ''}{pnl:,.0f}円{closed_text}\n\n"
        f"**■ 保有ポジション（{len(positions)}/{MAX_TOTAL}）**"
        f"{pos_text if pos_text else chr(10)+'  なし'}\n\n"
        f"**■ 戦略別ポジション**\n{strategy_lines}\n\n"
        f"取引状態: {'⛔ 停止中' if log['daily_loss_stopped'] else '✅ 稼働中'}",
        webhook
    )

    mt5.shutdown()

if __name__ == '__main__':
    main()
