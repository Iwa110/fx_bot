"""
リスク管理モジュール
- 案A：残高の1.5%をリスク額として固定
- 案B：ATRベースでSL幅を動的計算→ロットを逆算
- 将来の案C（ケリー基準）に備えて勝率・RRを記録
"""
import json, os
from datetime import datetime

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
STATS_PATH = os.path.join(BASE_DIR, 'strategy_stats.json')

RISK_PCT   = 0.015   # 残高の1.5%をリスク許容額
MIN_LOT    = 0.01    # 最小ロット
MAX_LOT    = 1.0     # 最大ロット（急変動時の上限）
USDJPY     = 150.0   # 円換算レート

# ── ロット計算（案A+B） ───────────────────────
def calc_lot(balance: float, sl_dist: float, symbol: str) -> float:
    """
    残高×リスク率 ÷ SL幅（円換算）でロットを計算

    Args:
        balance:  現在の口座残高（円）
        sl_dist:  SL幅（価格単位）
        symbol:   通貨ペア名

    Returns:
        ロット数（0.01単位に丸め）
    """
    risk_amount = balance * RISK_PCT  # リスク許容額（円）
    is_jpy      = 'JPY' in symbol

    # 1ロット(10,000通貨)あたりの1pip損失額（円）
    if is_jpy:
        # JPYペア: sl_dist円 × 10,000通貨 = sl_dist × 10,000円/ロット
        loss_per_lot = sl_dist * 10_000
    else:
        # 非JPYペア: sl_dist USD × 10,000通貨 × USDJPY = sl_dist × 10,000 × USDJPY円/ロット
        loss_per_lot = sl_dist * 10_000 * USDJPY

    if loss_per_lot <= 0:
        return MIN_LOT

    lot = risk_amount / loss_per_lot
    lot = round(lot, 2)
    lot = max(MIN_LOT, min(MAX_LOT, lot))

    # 0.01単位に丸める
    lot = round(lot / 0.01) * 0.01
    return lot

# ── ATRベースTP/SL計算 ────────────────────────
def calc_tp_sl(atr: float, strategy: str) -> tuple:
    """
    戦略ごとのATR乗数でTP/SL幅を計算

    Returns:
        (tp_dist, sl_dist): 価格単位
    """
    MULTIPLIERS = {
        'TRI':     {'tp': 1.5, 'sl': 4.0},   # 平均回帰・狭めSL
        'MOM_JPY': {'tp': 3.0, 'sl': 1.0},   # トレンド・広めTP
        'MOM_GBJ': {'tp': 3.5, 'sl': 1.0},   # ボラ高・広めTP
        'CORR':    {'tp': 2.5, 'sl': 1.5},   # 平均回帰・中程度
        'STR':     {'tp': 2.5, 'sl': 1.5},   # 強弱・中程度
        'BB':      {'tp': 3.0, 'sl': 2.0},   # 逆張り・標準
    }
    # BB_USDCADなどのプレフィックス対応
    key = strategy.split('_')[0] if '_' in strategy else strategy
    mult = MULTIPLIERS.get(key, {'tp': 2.0, 'sl': 1.5})

    tp_dist = atr * mult['tp']
    sl_dist = atr * mult['sl']
    return tp_dist, sl_dist

# ── 統計記録（ケリー基準準備） ────────────────
def load_stats() -> dict:
    if os.path.exists(STATS_PATH):
        with open(STATS_PATH, encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_stats(stats: dict):
    with open(STATS_PATH, 'w', encoding='utf-8') as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

def record_trade(strategy: str, profit: float, sl_dist: float,
                 tp_dist: float, entry: float):
    """
    取引結果を記録（将来のケリー基準計算用）

    Args:
        strategy: 戦略名
        profit:   損益（円）
        sl_dist:  SL幅
        tp_dist:  TP幅
        entry:    エントリー価格
    """
    stats = load_stats()
    if strategy not in stats:
        stats[strategy] = {
            'trades':    [],
            'total':     0,
            'wins':      0,
            'losses':    0,
            'total_pnl': 0,
            'avg_win':   0,
            'avg_loss':  0,
            'win_rate':  0,
            'avg_rr':    0,
            'kelly':     0,
            'last_updated': ''
        }

    s         = stats[strategy]
    is_win    = profit > 0
    rr_actual = abs(profit) / (sl_dist * 10_000) if sl_dist > 0 else 0

    s['trades'].append({
        'time':    datetime.now().strftime('%Y-%m-%d %H:%M'),
        'profit':  round(profit, 0),
        'result':  'win' if is_win else 'loss',
        'rr':      round(rr_actual, 2),
    })
    # 直近200件のみ保持
    s['trades'] = s['trades'][-200:]

    s['total']     += 1
    s['total_pnl'] += profit
    if is_win:
        s['wins'] += 1
    else:
        s['losses'] += 1

    # 統計再計算
    wins   = [t for t in s['trades'] if t['result']=='win']
    losses = [t for t in s['trades'] if t['result']=='loss']

    s['win_rate'] = round(s['wins'] / s['total'] * 100, 1) if s['total'] > 0 else 0
    s['avg_win']  = round(sum(t['profit'] for t in wins)   / len(wins),   0) if wins   else 0
    s['avg_loss'] = round(sum(t['profit'] for t in losses) / len(losses), 0) if losses else 0
    s['avg_rr']   = round(sum(t['rr']     for t in wins)   / len(wins),   2) if wins   else 0

    # ケリー基準計算（将来の参考値）
    if s['total'] >= 20:  # 20回以上で計算
        w = s['win_rate'] / 100
        r = s['avg_rr'] if s['avg_rr'] > 0 else 1.5
        kelly = w - (1 - w) / r
        s['kelly'] = round(max(0, kelly), 3)

    s['last_updated'] = datetime.now().strftime('%Y-%m-%d %H:%M')
    stats[strategy]   = s
    save_stats(stats)

def get_kelly_lot(strategy: str, balance: float,
                  sl_dist: float, symbol: str) -> float:
    """
    ケリー基準ロット計算（20回以上の記録がある場合）
    記録が少ない場合は案A+Bにフォールバック
    """
    stats = load_stats()
    s     = stats.get(strategy, {})

    if s.get('total', 0) < 20 or s.get('kelly', 0) <= 0:
        return calc_lot(balance, sl_dist, symbol)

    kelly     = s['kelly']
    half_kelly = kelly * 0.5  # ハーフケリーを使用
    risk_pct  = min(half_kelly, 0.03)  # 最大3%に制限

    is_jpy       = 'JPY' in symbol
    loss_per_lot = sl_dist * 10_000 * (1 if is_jpy else USDJPY)
    risk_amount  = balance * risk_pct
    lot          = risk_amount / loss_per_lot if loss_per_lot > 0 else MIN_LOT
    lot          = round(lot / 0.01) * 0.01
    return max(MIN_LOT, min(MAX_LOT, lot))

def print_stats_summary():
    """全戦略の統計サマリーを表示"""
    stats = load_stats()
    if not stats:
        print("記録なし")
        return

    print(f"\n{'='*60}")
    print("【戦略別統計・ケリー基準】")
    print(f"{'='*60}")
    print(f"  {'戦略':<12} {'取引':>5} {'勝率':>6} {'平均RR':>7} "
          f"{'Kelly':>7} {'総損益':>10}")
    print(f"  {'-'*55}")

    for strategy, s in sorted(stats.items()):
        kelly_str = f"{s['kelly']:.3f}" if s.get('kelly', 0) > 0 else "未算出"
        print(f"  {strategy:<12} {s['total']:>5}回 {s['win_rate']:>5.1f}% "
              f"{s['avg_rr']:>7.2f} {kelly_str:>7} "
              f"{s['total_pnl']:>+10,.0f}円")

    print(f"{'='*60}")
    print("  ※ケリー基準は20回以上の取引で算出")
    print("  ※実装はハーフケリー（Kelly×0.5）を使用")

if __name__ == '__main__':
    print_stats_summary()
