"""
FX 自動発注システム
- MT5 Python APIでリアルタイム価格取得
- シグナル検知 → 自動発注
- Discord通知
- 安全機能（最大3ポジション・1日損失3%停止）
"""
import MetaTrader5 as mt5
import json, os, time, urllib.request
from datetime import datetime, date

# ── 設定 ────────────────────────────────────
ENV_PATH = os.path.join(os.path.dirname(__file__), '.env')
RESULT_PATH = os.path.join(os.path.dirname(__file__), 'fx_v2_result.json')

MAX_POSITIONS = 3       # 最大同時ポジション数
MAX_LOSS_PCT  = 0.03    # 1日最大損失率（3%）
LOT_SIZE      = 0.1     # 発注ロット数
DEMO_MODE     = True    # Trueの間はデモ口座のみ発注可

# ── .env読み込み ──────────────────────────────
def load_env():
    config = {}
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH) as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    k, v = line.strip().split('=', 1)
                    config[k] = v
    return config

# ── Discord通知 ───────────────────────────────
def send_discord(message: str, webhook: str):
    data = json.dumps({'content': message}).encode('utf-8')
    req = urllib.request.Request(
        webhook, data=data,
        headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0'}
    )
    try:
        urllib.request.urlopen(req)
    except Exception as e:
        print(f"Discord送信エラー: {e}")

# ── MT5接続 ───────────────────────────────────
def connect_mt5():
    if not mt5.initialize():
        raise RuntimeError(f"MT5接続失敗: {mt5.last_error()}")
    info = mt5.account_info()
    print(f"MT5接続成功: {info.company} / 残高:{info.balance}")
    if DEMO_MODE and 'demo' not in info.server.lower() and 'Demo' not in info.server:
        raise RuntimeError("DEMO_MODEがTrueですが本番口座が検出されました。停止します。")
    return info

# ── 価格取得 ──────────────────────────────────
def get_price(symbol: str) -> dict:
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return None
    return {'bid': tick.bid, 'ask': tick.ask, 'mid': (tick.bid + tick.ask) / 2}

# ── ポジション確認 ────────────────────────────
def get_positions():
    positions = mt5.positions_get()
    return positions if positions else []

def count_positions():
    return len(get_positions())

# ── 1日損失チェック ───────────────────────────
def check_daily_loss(initial_balance: float) -> bool:
    info = mt5.account_info()
    loss_pct = (initial_balance - info.equity) / initial_balance
    if loss_pct >= MAX_LOSS_PCT:
        print(f"1日損失上限({MAX_LOSS_PCT*100}%)到達。本日の取引を停止します。")
        return False
    return True

# ── シグナル判定 ──────────────────────────────
def check_signals(params: dict) -> list:
    signals = []

    # TRI: EUR/GBP三角裁定
    eurusd = get_price('EURUSD')
    gbpusd = get_price('GBPUSD')
    eurgbp = get_price('EURGBP')

    if eurusd and gbpusd and eurgbp:
        theory = eurusd['mid'] / gbpusd['mid']
        spread = eurgbp['mid'] - theory
        if abs(spread) >= params.get('tri_entry', 0.0022):
            direction = 'sell' if spread > 0 else 'buy'
            signals.append({
                'strategy': 'TRI',
                'symbol': 'EURGBP',
                'direction': direction,
                'entry': eurgbp['ask'] if direction == 'buy' else eurgbp['bid'],
                'tp_dist': params.get('tri_exit', 0.0007),
                'sl_dist': params.get('tri_stop', 0.0055),
                'reason': f"三角裁定乖離={spread:.5f}"
            })

    # MOM: GBPモメンタム（簡易版・直近足で判定）
    gbp_rates = mt5.copy_rates_from_pos('GBPUSD', mt5.TIMEFRAME_D1, 0, 11)
    eur_rates = mt5.copy_rates_from_pos('EURUSD', mt5.TIMEFRAME_D1, 0, 11)
    if gbp_rates is not None and eur_rates is not None and len(gbp_rates) >= 11:
        gbp_mom = (gbp_rates[-1]['close'] - gbp_rates[-11]['close']) / gbp_rates[-11]['close']
        eur_mom = (eur_rates[-1]['close'] - eur_rates[-11]['close']) / eur_rates[-11]['close']
        mom_th  = params.get('mom_th', 0.01)
        eur_th  = params.get('mom_eur_th', 0.005)
        if gbp_mom > mom_th and eur_mom > eur_th:
            direction = 'buy'
        elif gbp_mom < -mom_th and eur_mom < -eur_th:
            direction = 'sell'
        else:
            direction = None
        if direction:
            price = gbpusd['ask'] if direction == 'buy' else gbpusd['bid']
            signals.append({
                'strategy': 'MOM',
                'symbol': 'GBPUSD',
                'direction': direction,
                'entry': price,
                'tp_dist': price * params.get('mom_tp_pct', 0.027),
                'sl_dist': price * params.get('mom_sl_pct', 0.013),
                'reason': f"GBPモメンタム={gbp_mom*100:.2f}%"
            })

    return signals

# ── 発注 ─────────────────────────────────────
def place_order(signal: dict) -> bool:
    symbol   = signal['symbol']
    direction = signal['direction']
    entry    = signal['entry']
    tp_dist  = signal['tp_dist']
    sl_dist  = signal['sl_dist']

    order_type = mt5.ORDER_TYPE_BUY if direction == 'buy' else mt5.ORDER_TYPE_SELL
    tp = entry + tp_dist if direction == 'buy' else entry - tp_dist
    sl = entry - sl_dist if direction == 'buy' else entry + sl_dist

    request = {
        'action':   mt5.TRADE_ACTION_DEAL,
        'symbol':   symbol,
        'volume':   LOT_SIZE,
        'type':     order_type,
        'price':    entry,
        'tp':       round(tp, 5),
        'sl':       round(sl, 5),
        'deviation': 20,
        'magic':    20240101,
        'comment':  f"FXBot_{signal['strategy']}",
        'type_time': mt5.ORDER_TIME_GTC,
        'type_filling': mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)
    if result.retcode == mt5.TRADE_RETCODE_DONE:
        print(f"発注成功: {symbol} {direction} @ {entry}")
        return True
    else:
        print(f"発注失敗: {result.retcode} / {result.comment}")
        return False

# ── メイン ────────────────────────────────────
def main():
    config = load_env()
    webhook = config.get('DISCORD_WEBHOOK', '')

    # MT5接続
    info = connect_mt5()
    initial_balance = info.balance
    now = datetime.now().strftime('%Y-%m-%d %H:%M')

    # パラメーター読み込み
    with open(RESULT_PATH) as f:
        result = json.load(f)
    params = result['best_params']

    # 安全チェック
    if not check_daily_loss(initial_balance):
        send_discord(f"【FX Bot】{now}\n⛔ 1日損失上限に達したため本日の取引を停止しました。", webhook)
        mt5.shutdown()
        return

    if count_positions() >= MAX_POSITIONS:
        print(f"最大ポジション数({MAX_POSITIONS})に達しています。スキップします。")
        mt5.shutdown()
        return

    # シグナル検知
    signals = check_signals(params)

    if not signals:
        msg = f"【FX Bot】{now}\n🔵 シグナルなし・待機中"
        print(msg)
        send_discord(msg, webhook)
        mt5.shutdown()
        return

    # 発注
    results = []
    for sig in signals:
        if count_positions() >= MAX_POSITIONS:
            break
        success = place_order(sig)
        status = "✅ 発注成功" if success else "❌ 発注失敗"
        results.append(f"{status} {sig['symbol']} {sig['direction']} ({sig['reason']})")

    # 発注結果をDiscordに通知
    msg = f"【FX Bot】{now}\n\n🟢 自動発注実行\n\n" + '\n'.join(results)
    msg += f"\n\n現在ポジション数: {count_positions()}/{MAX_POSITIONS}"
    msg += "\n⚠️ 自動発注システム稼働中"
    send_discord(msg, webhook)

    mt5.shutdown()

if __name__ == '__main__':
    main()
